liste_nasa = dicoNasa=[{'objet': 'allumettes', 'valeur': '01', 'poids': '0.1'}, {'objet': 'aliments', 'valeur': '12', 'poids': '2'}, {'objet': 'corde', 'valeur': '10', 'poids': '5'}, {'objet': 'parachute', 'valeur': '08', 'poids': '0.5'}, {'objet': 'chauffage', 'valeur': '03', 'poids': '25'}, {'objet': 'pistolets', 'valeur': '05', 'poids': '0.5'}, {'objet': 'lait', 'valeur': '04', 'poids': '5'}, {'objet': 'oxygène', 'valeur': '15', 'poids': '100'}, {'objet': 'carte', 'valeur': '13', 'poids': '0.1'}, {'objet': 'canot', 'valeur': '07', 'poids': '100'}, {'objet': 'compas', 'valeur': '02', 'poids': '0.5'}, {'objet': 'eau', 'valeur': '14', 'poids': '25'}, {'objet': 'seringues', 'valeur': '09', 'poids': '0.5'}, {'objet': 'signaux', 'valeur': '06', 'poids': '1'}, {'objet': 'emetteur', 'valeur': '11', 'poids': '5'}]

poids_max = 250 

# initialisations
cumul_poids = 0
cumul_valeur = 0
choix = []

# on trie la liste mercato par force décroissante  ATTENTION DIFFICULTE ELEVE
# CECI EST L'ETAPE CLE POUR QUALIFIER L'ALGORITHME DE GLOUTON
liste_nasa_ordo =sorted(liste_nasa, key=lambda d: d["valeur"], reverse=True)
print (liste_nasa_ordo)
# on balaye sequentiellement liste_nasa_ordo
for i in range(len(liste_nasa_ordo)):  
    # on accumule tant que cela ne va pas dépasser le budget Poids
    # et que l'on ne dépasse pas le nombre d'objet, fixé à 10 par nos contraintes
    if cumul_poids + float(liste_nasa_ordo[i]["poids"]) <= poids_max and len(choix)<10: 
        cumul_valeur += int(liste_nasa_ordo[i]["valeur"])  #calcul valeur gagnée
        choix.append(liste_nasa_ordo[i])             #complément liste des recrues
        cumul_poids += float(liste_nasa_ordo[i]["poids"])  #calcul poids "dépensées"

#Affichage du résultat
print ("somme des valeurs : ",cumul_valeur)
print ("nombre d'objet : ",len(choix))
print ("poids total : ",cumul_poids)
print ("\nliste des objets\n")
for i in range(len(choix)):
    print (choix[i]["objet"], choix[i]["valeur"],"poids", choix[i]["poids"])
